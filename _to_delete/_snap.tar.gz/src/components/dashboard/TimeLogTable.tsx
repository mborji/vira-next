import React from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Edit } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  ALLOWED_ARRIVAL_TIME,
  formatClock,
  formatDuration,
  formatHours,
  formatJalaliFromDbDate,
  formatMinutesAsClock,
  formatMinutesLabel,
  getArrivalMinutes,
  getDelayMinutes,
  getDepartureMinutes,
  getInitials,
  loggedHoursOf,
  type OverviewTimeLog,
} from "@/components/worker/overview/workerStats";
// The 9-hour company day is the single source of truth for every derived
// number here — never redeclare it locally (see monthlyWorkQuota.ts).
import { COMPANY_DAILY_HOURS } from "@/components/worker/overview/monthlyWorkQuota";

/**
 * Full width of the کارکرد bar. One hour above a complete working day, so an
 * overtime row still has somewhere to grow and two rows stay comparable.
 */
const PROGRESS_MAX_HOURS = COMPANY_DAILY_HOURS + 1;

export interface TimeLogTableLog extends OverviewTimeLog {
  worker_id: string;
  worker_name?: string | null;
}

export interface TimeLogTableWorker {
  user_id: string;
  full_name?: string | null;
  email?: string | null;
  /**
   * The database only allows `full_time` / `part_time` today (a CHECK
   * constraint on `profiles.worker_type`). Adding an `hourly` type later is a
   * one-line change in {@link WORKER_TYPE_STYLES}.
   */
  worker_type?: string | null;
}

/** عادی / اضافه‌کاری / تأخیر / غیبت — derived, never stored. */
export type AttendanceStatus = "normal" | "overtime" | "late" | "absent";

const WORKER_TYPE_STYLES: Record<
  string,
  { label: string; className: string }
> = {
  full_time: {
    label: "تمام‌وقت",
    className:
      "border-sky-200/70 bg-sky-50 text-sky-700 dark:border-sky-800/60 dark:bg-sky-950/50 dark:text-sky-300",
  },
  part_time: {
    label: "پاره‌وقت",
    className:
      "border-orange-200/70 bg-orange-50 text-orange-700 dark:border-orange-800/60 dark:bg-orange-950/50 dark:text-orange-300",
  },
  // hourly: {
  //   label: "ساعتی",
  //   className:
  //     "border-violet-200/70 bg-violet-50 text-violet-700 dark:border-violet-800/60 dark:bg-violet-950/50 dark:text-violet-300",
  // },
};

const STATUS_STYLES: Record<
  AttendanceStatus,
  { label: string; badge: string; bar: string }
> = {
  normal: {
    label: "عادی",
    badge:
      "border-emerald-200/70 bg-emerald-50 text-emerald-700 dark:border-emerald-800/60 dark:bg-emerald-950/50 dark:text-emerald-300",
    bar: "bg-emerald-500",
  },
  overtime: {
    label: "اضافه‌کاری",
    badge:
      "border-emerald-300 bg-emerald-100 text-emerald-800 dark:border-emerald-700 dark:bg-emerald-900/60 dark:text-emerald-200",
    bar: "bg-emerald-600",
  },
  late: {
    label: "تأخیر",
    badge:
      "border-amber-200/70 bg-amber-50 text-amber-700 dark:border-amber-800/60 dark:bg-amber-950/50 dark:text-amber-300",
    bar: "bg-amber-500",
  },
  absent: {
    label: "غیبت",
    badge:
      "border-red-200/70 bg-red-50 text-red-700 dark:border-red-800/60 dark:bg-red-950/50 dark:text-red-300",
    bar: "",
  },
};

/** Fixed avatar palette — the colour is derived from the name, so it never changes between renders. */
const AVATAR_COLORS = [
  "bg-sky-500",
  "bg-violet-500",
  "bg-emerald-500",
  "bg-amber-500",
  "bg-rose-500",
  "bg-teal-500",
  "bg-indigo-500",
  "bg-fuchsia-500",
];

const avatarColorOf = (seed: string): string => {
  let hash = 0;
  for (let index = 0; index < seed.length; index += 1) {
    hash = (hash * 31 + seed.charCodeAt(index)) >>> 0;
  }
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
};

interface DerivedRow {
  log: TimeLogTableLog;
  name: string;
  email: string;
  workerType: string | null;
  hours: number;
  arrival: string;
  departure: string;
  delayMinutes: number | null;
  status: AttendanceStatus;
  percent: number;
}

/**
 * Status precedence: a day with no clock-in at all is غیبت; otherwise a full
 * working day plus extra is اضافه‌کاری even when the arrival was late (the
 * hours were made up), then تأخیر, then عادی.
 */
const deriveStatus = (
  hours: number,
  arrivalMinutes: number | null,
  delayMinutes: number | null
): AttendanceStatus => {
  if (arrivalMinutes === null && hours <= 0) return "absent";
  if (hours > COMPANY_DAILY_HOURS) return "overtime";
  if (delayMinutes !== null && delayMinutes > 0) return "late";
  return "normal";
};

const EM_DASH = "—";

/**
 * Column widths. The table is `table-fixed`, so these are authoritative: a long
 * name or a two-digit hour count can never widen a column and shift the ones
 * beside it. Anything that could overflow (name, email, description) truncates
 * instead. Declared once and applied to the `<th>` only — the browser takes the
 * whole column's width from the header row.
 */
const COLUMN_WIDTHS = {
  worker: "w-[220px]",
  type: "w-[92px]",
  date: "w-[104px]",
  arrival: "w-[76px]",
  departure: "w-[76px]",
  work: "w-[150px]",
  status: "w-[104px]",
  description: "w-[150px]",
  actions: "w-[56px]",
} as const;

const buildRow = (
  log: TimeLogTableLog,
  worker?: TimeLogTableWorker
): DerivedRow => {
  const single = [log];
  const hours = loggedHoursOf(log);
  const arrivalMinutes = getArrivalMinutes(single);
  const departureMinutes = getDepartureMinutes(single);
  const delayMinutes = getDelayMinutes(single);
  const status = deriveStatus(hours, arrivalMinutes, delayMinutes);

  return {
    log,
    name: worker?.full_name || log.worker_name || "نامشخص",
    email: worker?.email || "",
    workerType: worker?.worker_type ?? null,
    hours,
    // Earliest clock-in / latest clock-out across both shifts, so a day logged
    // out of order still shows the real ورود and خروج.
    arrival: formatMinutesAsClock(arrivalMinutes),
    departure: formatMinutesAsClock(departureMinutes),
    delayMinutes,
    status,
    percent:
      status === "absent"
        ? 0
        : Math.min(100, Math.round((hours / PROGRESS_MAX_HOURS) * 100)),
  };
};

const WorkerCell: React.FC<{ name: string; email: string }> = ({
  name,
  email,
}) => (
  <div className="flex items-center gap-3">
    <Avatar className="h-9 w-9 shrink-0">
      <AvatarFallback
        className={cn(
          "text-[11px] font-bold text-white",
          avatarColorOf(name || email || "?")
        )}
      >
        {getInitials(name, email)}
      </AvatarFallback>
    </Avatar>
    <div className="min-w-0">
      <div className="truncate font-bold text-foreground">{name}</div>
      {email ? (
        <div className="truncate text-[11px] text-muted-foreground">
          {email}
        </div>
      ) : null}
    </div>
  </div>
);

const WorkerTypeBadge: React.FC<{ workerType: string | null }> = ({
  workerType,
}) => {
  const style = workerType ? WORKER_TYPE_STYLES[workerType] : undefined;
  if (!style) {
    return <span className="text-xs text-muted-foreground">{EM_DASH}</span>;
  }
  return (
    <Badge
      variant="outline"
      className={cn("rounded-full px-3 py-0.5 text-[11px]", style.className)}
    >
      {style.label}
    </Badge>
  );
};

const StatusBadge: React.FC<{ status: AttendanceStatus; title?: string }> = ({
  status,
  title,
}) => (
  <Badge
    variant="outline"
    title={title}
    className={cn(
      "rounded-full px-3 py-0.5 text-[11px]",
      STATUS_STYLES[status].badge
    )}
  >
    {STATUS_STYLES[status].label}
  </Badge>
);

/**
 * The کارکرد bar. Deliberately not `ui/progress`: that primitive positions its
 * indicator with `translateX`, which is physical and would fill from the left
 * inside this globally `dir="rtl"` app. A plain block fills from the inline
 * start, so it grows from the right here with no direction branch at all.
 */
const WorkHoursBar: React.FC<{ hours: number; percent: number; status: AttendanceStatus }> = ({
  hours,
  percent,
  status,
}) => {
  const standardMark = (COMPANY_DAILY_HOURS / PROGRESS_MAX_HOURS) * 100;

  return (
    <div className="space-y-1">
      <div className="text-xs font-semibold text-foreground">
        {`${formatHours(hours)} ساعت`}
      </div>
      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={PROGRESS_MAX_HOURS}
        aria-valuenow={Math.round(hours * 10) / 10}
        title={`${formatDuration(hours)} از ${formatDuration(
          COMPANY_DAILY_HOURS
        )} ساعت روز کاری`}
        className="relative h-1.5 w-full min-w-[90px] overflow-hidden rounded-full bg-muted"
      >
        <div
          className={cn("h-full rounded-full transition-all", STATUS_STYLES[status].bar)}
          style={{ width: `${percent}%` }}
        />
        <span
          aria-hidden
          className="absolute inset-y-0 w-px bg-foreground/20"
          style={{ insetInlineStart: `${standardMark}%` }}
        />
      </div>
    </div>
  );
};

export interface TimeLogTableProps {
  logs: TimeLogTableLog[];
  workers: TimeLogTableWorker[];
  onEdit?: (log: TimeLogTableLog) => void;
  className?: string;
}

/**
 * «ساعات کاری ثبت شده» — one row per registered time log. Absence is *not*
 * synthesised here: a day with no record simply has no row. A row only reads
 * as غیبت when its own clock-in and clock-out are empty.
 */
export const TimeLogTable: React.FC<TimeLogTableProps> = ({
  logs,
  workers,
  onEdit,
  className,
}) => {
  const workerById = React.useMemo(() => {
    const map = new Map<string, TimeLogTableWorker>();
    workers.forEach((worker) => map.set(worker.user_id, worker));
    return map;
  }, [workers]);

  const rows = React.useMemo(
    () => logs.map((log) => buildRow(log, workerById.get(log.worker_id))),
    [logs, workerById]
  );

  const delayTitle = (row: DerivedRow) =>
    row.status === "late" && row.delayMinutes
      ? `${formatMinutesLabel(row.delayMinutes)} دیرتر از ${formatClock(
          ALLOWED_ARRIVAL_TIME
        )}`
      : undefined;

  if (rows.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border/70 py-10 text-center text-sm text-muted-foreground">
        برای این بازه هیچ ساعت کاری ثبت نشده است.
      </div>
    );
  }

  return (
    <div className={className}>
      {/* دسکتاپ: جدول با اسکرول افقی */}
      <div className="hidden overflow-x-auto md:block">
        <Table className="min-w-[1000px] table-fixed">
          <TableHeader>
            {/* `TableHead` in ui/table.tsx is physically `text-left`, while the cells
                inherit `text-right` from the RTL root — so every heading would sit on
                the opposite edge from its own column. `text-start` is logical and the
                child selector outranks it. */}
            <TableRow className="border-b border-border/60 bg-muted/50 hover:bg-muted/50 [&>th]:text-start">
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.worker)}>
                کارمند
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.type)}>
                نوع
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.date)}>
                تاریخ
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.arrival)}>
                ورود
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.departure)}>
                خروج
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.work)}>
                کارکرد
              </TableHead>
              <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.status)}>
                وضعیت
              </TableHead>
              <TableHead
                className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.description)}
              >
                توضیحات
              </TableHead>
              {/* Rendered under exactly the same condition as its cell below, so a
                  read-only table can never end up one column short. */}
              {onEdit ? (
                <TableHead className={cn("h-11 text-xs font-bold", COLUMN_WIDTHS.actions)}>
                  عملیات
                </TableHead>
              ) : null}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row.log.id}
                className="border-b border-border/50 text-start align-middle transition-colors hover:bg-muted/30"
              >
                <TableCell className="py-3">
                  <WorkerCell name={row.name} email={row.email} />
                </TableCell>
                <TableCell className="py-3">
                  <WorkerTypeBadge workerType={row.workerType} />
                </TableCell>
                <TableCell className="py-3 text-xs font-medium text-foreground/80">
                  <span dir="ltr">{formatJalaliFromDbDate(row.log.date)}</span>
                </TableCell>
                <TableCell
                  className={cn(
                    "py-3 font-bold",
                    row.arrival === EM_DASH
                      ? "text-muted-foreground"
                      : "text-emerald-600 dark:text-emerald-400"
                  )}
                  dir="ltr"
                >
                  {row.arrival}
                </TableCell>
                <TableCell
                  className={cn(
                    "py-3 font-bold",
                    row.departure === EM_DASH
                      ? "text-muted-foreground"
                      : "text-sky-600 dark:text-sky-400"
                  )}
                  dir="ltr"
                >
                  {row.departure}
                </TableCell>
                <TableCell className="py-3">
                  {row.status === "absent" ? (
                    <span className="text-muted-foreground">{EM_DASH}</span>
                  ) : (
                    <WorkHoursBar
                      hours={row.hours}
                      percent={row.percent}
                      status={row.status}
                    />
                  )}
                </TableCell>
                <TableCell className="py-3">
                  <StatusBadge status={row.status} title={delayTitle(row)} />
                </TableCell>
                <TableCell className="py-3 text-xs text-muted-foreground">
                  <span
                    className="line-clamp-2"
                    title={row.log.description || undefined}
                  >
                    {row.log.description || EM_DASH}
                  </span>
                </TableCell>
                {onEdit ? (
                  <TableCell className="py-3">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0"
                      aria-label="ویرایش ساعت کاری"
                      onClick={() => onEdit(row.log)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </TableCell>
                ) : null}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* موبایل: هر ردیف یک کارت */}
      <div className="space-y-3 md:hidden">
        {rows.map((row) => (
          <div
            key={row.log.id}
            className="rounded-xl border border-border/60 bg-card p-3 shadow-sm"
          >
            <div className="flex items-start justify-between gap-2">
              <WorkerCell name={row.name} email={row.email} />
              <StatusBadge status={row.status} title={delayTitle(row)} />
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
              <span className="text-muted-foreground" dir="ltr">
                {formatJalaliFromDbDate(row.log.date)}
              </span>
              <WorkerTypeBadge workerType={row.workerType} />
            </div>

            <div className="mt-2 flex items-center gap-4 text-xs">
              <span>
                <span className="text-muted-foreground">ورود: </span>
                <span
                  className={cn(
                    "font-bold",
                    row.arrival === EM_DASH
                      ? "text-muted-foreground"
                      : "text-emerald-600 dark:text-emerald-400"
                  )}
                  dir="ltr"
                >
                  {row.arrival}
                </span>
              </span>
              <span>
                <span className="text-muted-foreground">خروج: </span>
                <span
                  className={cn(
                    "font-bold",
                    row.departure === EM_DASH
                      ? "text-muted-foreground"
                      : "text-sky-600 dark:text-sky-400"
                  )}
                  dir="ltr"
                >
                  {row.departure}
                </span>
              </span>
            </div>

            {row.status === "absent" ? null : (
              <div className="mt-3">
                <WorkHoursBar
                  hours={row.hours}
                  percent={row.percent}
                  status={row.status}
                />
              </div>
            )}

            {row.log.description ? (
              <p className="mt-2 text-xs text-muted-foreground">
                {row.log.description}
              </p>
            ) : null}

            {onEdit ? (
              <Button
                size="sm"
                variant="outline"
                className="mt-3 w-full"
                onClick={() => onEdit(row.log)}
              >
                <Edit className="ms-2 h-4 w-4" />
                ویرایش
              </Button>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TimeLogTable;
